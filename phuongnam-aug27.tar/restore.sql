--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: adminpack; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS adminpack WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION adminpack; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION adminpack IS 'administrative functions for PostgreSQL';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assignments (
    "createdAt" timestamp(6) with time zone NOT NULL,
    "updatedAt" timestamp(6) with time zone NOT NULL,
    "userId" integer NOT NULL,
    "taskId" integer NOT NULL
);


ALTER TABLE public.assignments OWNER TO postgres;

--
-- Name: criteria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.criteria (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "requirementLevel" character varying(255) NOT NULL,
    method character varying(255) NOT NULL,
    "createdAt" timestamp(6) with time zone NOT NULL,
    "updatedAt" timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.criteria OWNER TO postgres;

--
-- Name: criteria_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.criteria_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.criteria_id_seq OWNER TO postgres;

--
-- Name: criteria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.criteria_id_seq OWNED BY public.criteria.id;


--
-- Name: dossier_products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dossier_products (
    "createdAt" timestamp(6) with time zone NOT NULL,
    "updatedAt" timestamp(6) with time zone NOT NULL,
    "productId" integer NOT NULL,
    "dossierId" integer NOT NULL,
    "sampleCount" integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.dossier_products OWNER TO postgres;

--
-- Name: dossiers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dossiers (
    id integer NOT NULL,
    reference_id character varying(255) NOT NULL,
    branch character varying(255) NOT NULL,
    collection_deadline timestamp with time zone NOT NULL,
    dossier_deadline timestamp with time zone NOT NULL,
    overall_status character varying(255) DEFAULT 'Chưa bắt đầu'::character varying NOT NULL,
    completion_date timestamp with time zone,
    "createdAt" timestamp(6) with time zone NOT NULL,
    "updatedAt" timestamp(6) with time zone NOT NULL,
    intake_employee integer NOT NULL,
    image bytea[]
);


ALTER TABLE public.dossiers OWNER TO postgres;

--
-- Name: dossiers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dossiers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dossiers_id_seq OWNER TO postgres;

--
-- Name: dossiers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dossiers_id_seq OWNED BY public.dossiers.id;


--
-- Name: equipment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.equipment (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    quantity integer NOT NULL,
    notes character varying(255),
    "minRole" character varying(255) DEFAULT 'untrained'::character varying NOT NULL,
    "createdAt" timestamp(6) with time zone NOT NULL,
    "updatedAt" timestamp(6) with time zone NOT NULL,
    "freeQuantity" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.equipment OWNER TO postgres;

--
-- Name: equipment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.equipment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.equipment_id_seq OWNER TO postgres;

--
-- Name: equipment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.equipment_id_seq OWNED BY public.equipment.id;


--
-- Name: equipment_queues; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.equipment_queues (
    "taskId" integer NOT NULL,
    "equipmentId" integer,
    "position" integer NOT NULL,
    "createdAt" timestamp(6) with time zone NOT NULL,
    "updatedAt" timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.equipment_queues OWNER TO postgres;

--
-- Name: product_criteria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_criteria (
    "createdAt" timestamp(6) with time zone NOT NULL,
    "updatedAt" timestamp(6) with time zone NOT NULL,
    "criterionId" integer NOT NULL,
    "productId" integer NOT NULL,
    "equipmentId" integer,
    "sampleId" integer DEFAULT 1 NOT NULL,
    "inspectionOrder" integer DEFAULT 1 NOT NULL,
    "maxAssignees" integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.product_criteria OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "createdAt" timestamp(6) with time zone NOT NULL,
    "updatedAt" timestamp(6) with time zone NOT NULL,
    "collectionMethod" character varying(255) NOT NULL
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: sample_queues; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sample_queues (
    "taskId" integer NOT NULL,
    "dossierId" integer NOT NULL,
    "sampleId" integer NOT NULL,
    "position" integer NOT NULL,
    "createdAt" timestamp(6) with time zone NOT NULL,
    "updatedAt" timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.sample_queues OWNER TO postgres;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    dossier_id integer NOT NULL,
    product_id integer NOT NULL,
    criterion integer NOT NULL,
    status character varying(255) DEFAULT 'Chưa bắt đầu'::character varying NOT NULL,
    completion_date timestamp with time zone,
    notes character varying(1000),
    deadline timestamp with time zone,
    "createdAt" timestamp(6) with time zone NOT NULL,
    "updatedAt" timestamp(6) with time zone NOT NULL,
    images bytea[],
    "isActive" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    "firstName" character varying(255) NOT NULL,
    "lastName" character varying(255) NOT NULL,
    username character varying(255),
    passhash character varying(255),
    "createdAt" timestamp(6) with time zone NOT NULL,
    "updatedAt" timestamp(6) with time zone NOT NULL,
    email character varying(255),
    phone character varying(255),
    photo bytea,
    role character varying(255) DEFAULT 'admin'::character varying NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: criteria id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.criteria ALTER COLUMN id SET DEFAULT nextval('public.criteria_id_seq'::regclass);


--
-- Name: dossiers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dossiers ALTER COLUMN id SET DEFAULT nextval('public.dossiers_id_seq'::regclass);


--
-- Name: equipment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment ALTER COLUMN id SET DEFAULT nextval('public.equipment_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Data for Name: assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.assignments ("createdAt", "updatedAt", "userId", "taskId") FROM stdin;
\.
COPY public.assignments ("createdAt", "updatedAt", "userId", "taskId") FROM '$$PATH$$/3686.dat';

--
-- Data for Name: criteria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.criteria (id, name, "requirementLevel", method, "createdAt", "updatedAt") FROM stdin;
\.
COPY public.criteria (id, name, "requirementLevel", method, "createdAt", "updatedAt") FROM '$$PATH$$/3683.dat';

--
-- Data for Name: dossier_products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dossier_products ("createdAt", "updatedAt", "productId", "dossierId", "sampleCount") FROM stdin;
\.
COPY public.dossier_products ("createdAt", "updatedAt", "productId", "dossierId", "sampleCount") FROM '$$PATH$$/3687.dat';

--
-- Data for Name: dossiers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dossiers (id, reference_id, branch, collection_deadline, dossier_deadline, overall_status, completion_date, "createdAt", "updatedAt", intake_employee, image) FROM stdin;
\.
COPY public.dossiers (id, reference_id, branch, collection_deadline, dossier_deadline, overall_status, completion_date, "createdAt", "updatedAt", intake_employee, image) FROM '$$PATH$$/3690.dat';

--
-- Data for Name: equipment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.equipment (id, name, description, quantity, notes, "minRole", "createdAt", "updatedAt", "freeQuantity") FROM stdin;
\.
COPY public.equipment (id, name, description, quantity, notes, "minRole", "createdAt", "updatedAt", "freeQuantity") FROM '$$PATH$$/3692.dat';

--
-- Data for Name: equipment_queues; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.equipment_queues ("taskId", "equipmentId", "position", "createdAt", "updatedAt") FROM stdin;
\.
COPY public.equipment_queues ("taskId", "equipmentId", "position", "createdAt", "updatedAt") FROM '$$PATH$$/3693.dat';

--
-- Data for Name: product_criteria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_criteria ("createdAt", "updatedAt", "criterionId", "productId", "equipmentId", "sampleId", "inspectionOrder", "maxAssignees") FROM stdin;
\.
COPY public.product_criteria ("createdAt", "updatedAt", "criterionId", "productId", "equipmentId", "sampleId", "inspectionOrder", "maxAssignees") FROM '$$PATH$$/3688.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, name, "createdAt", "updatedAt", "collectionMethod") FROM stdin;
\.
COPY public.products (id, name, "createdAt", "updatedAt", "collectionMethod") FROM '$$PATH$$/3681.dat';

--
-- Data for Name: sample_queues; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sample_queues ("taskId", "dossierId", "sampleId", "position", "createdAt", "updatedAt") FROM stdin;
\.
COPY public.sample_queues ("taskId", "dossierId", "sampleId", "position", "createdAt", "updatedAt") FROM '$$PATH$$/3694.dat';

--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (id, dossier_id, product_id, criterion, status, completion_date, notes, deadline, "createdAt", "updatedAt", images, "isActive") FROM stdin;
\.
COPY public.tasks (id, dossier_id, product_id, criterion, status, completion_date, notes, deadline, "createdAt", "updatedAt", images, "isActive") FROM '$$PATH$$/3685.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, "firstName", "lastName", username, passhash, "createdAt", "updatedAt", email, phone, photo, role) FROM stdin;
\.
COPY public.users (id, "firstName", "lastName", username, passhash, "createdAt", "updatedAt", email, phone, photo, role) FROM '$$PATH$$/3679.dat';

--
-- Name: criteria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.criteria_id_seq', 19, true);


--
-- Name: dossiers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dossiers_id_seq', 160, true);


--
-- Name: equipment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.equipment_id_seq', 7, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_id_seq', 18, true);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tasks_id_seq', 1212, true);


--
-- Name: assignments assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT assignments_pkey PRIMARY KEY ("userId", "taskId");


--
-- Name: criteria criteria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.criteria
    ADD CONSTRAINT criteria_pkey PRIMARY KEY (id);


--
-- Name: dossiers dossiers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dossiers
    ADD CONSTRAINT dossiers_pkey PRIMARY KEY (id);


--
-- Name: equipment equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_pkey PRIMARY KEY (id);


--
-- Name: equipment_queues equipment_queues_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment_queues
    ADD CONSTRAINT equipment_queues_pkey PRIMARY KEY ("taskId");


--
-- Name: product_criteria product_criterions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_criteria
    ADD CONSTRAINT product_criterions_pkey PRIMARY KEY ("criterionId", "productId");


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: sample_queues sample_queues_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sample_queues
    ADD CONSTRAINT sample_queues_pkey PRIMARY KEY ("taskId");


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: assignments assignments_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT "assignments_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public.tasks(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assignments assignments_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT "assignments_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dossier_products dossier_products_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dossier_products
    ADD CONSTRAINT "dossier_products_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dossiers dossiers_intake_employee_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dossiers
    ADD CONSTRAINT dossiers_intake_employee_fkey FOREIGN KEY (intake_employee) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: equipment_queues equipment_queues_equipmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment_queues
    ADD CONSTRAINT "equipment_queues_equipmentId_fkey" FOREIGN KEY ("equipmentId") REFERENCES public.equipment(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: equipment_queues equipment_queues_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment_queues
    ADD CONSTRAINT "equipment_queues_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public.tasks(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_criteria product_criteria_equipmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_criteria
    ADD CONSTRAINT "product_criteria_equipmentId_fkey" FOREIGN KEY ("equipmentId") REFERENCES public.equipment(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: product_criteria product_criterions_criterionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_criteria
    ADD CONSTRAINT "product_criterions_criterionId_fkey" FOREIGN KEY ("criterionId") REFERENCES public.criteria(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_criteria product_criterions_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_criteria
    ADD CONSTRAINT "product_criterions_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sample_queues sample_queues_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sample_queues
    ADD CONSTRAINT "sample_queues_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public.tasks(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tasks tasks_criterion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_criterion_fkey FOREIGN KEY (criterion) REFERENCES public.criteria(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tasks tasks_dossier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_dossier_id_fkey FOREIGN KEY (dossier_id) REFERENCES public.dossiers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tasks tasks_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

